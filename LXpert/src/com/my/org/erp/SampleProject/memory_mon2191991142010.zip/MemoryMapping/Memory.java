
/*
<applet code=Memory   height=300 width=650>
</applet>
*/

import java.net.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import java.applet.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.lang.management.*;
import java.util.*;


public class Memory  extends JApplet  implements  MouseListener
{
 JPanel p1,p2,p3,p4;
 int j=60;
int j2=20;
int p=0;
int start=60,end=20;
int pre=0,nex=0;
int x1=60,y1=220;
int x2=60,y2=220;
JProgressBar jp;
int u=1,u2=1;
int count=2;
// Refreshment Rate
static int rate=1000;

  static java.util.List<MemoryPoolMXBean> mpools = 
        ManagementFactory.getMemoryPoolMXBeans();

	     int npool=1;
                      MemoryPoolMXBean mp =mpools.get(npool); 
	    float usedMemory =  mp.getUsage().getUsed();
                      float totalMemory =  mp.getUsage().getMax();

public Memory()
{

p1=new JPanel();
p1.setBounds(0,0,100,100);
p1.setBackground(Color.black);
add(p1);
repaint();

}
public void  mouseClicked(MouseEvent e)
{
try{
   wait(6000);
}catch(Exception f){}
}
public void  mouseEntered(MouseEvent e)
{
}
public void  mousePressed(MouseEvent e)
{
repaint();
}
public void  mouseExited(MouseEvent e)
{
}
public void  mouseReleased(MouseEvent e)
{
}



public void start()
{

}
public  void paint(Graphics g)
{
 int j=60;
int j2=20;
Color ccw;
if(count%2==0)
{
 ccw=new Color(u2+15,u2+51,u+30);
u2=u2+10;
u=u+50;
count++;
}
else{
 ccw=new Color(u2-10,u2+151,u-20);
u2=u2-10;
u=u-30;
count++;
}

g.setColor(Color.red);
g.drawString("High Memory",10,10);
g.drawLine(60,20,400,20);


g.setColor(Color.blue);



g.drawString("Midium",10,130);
Color cc=new Color(0,0,0);
g.setColor(cc);
g.drawLine(60,120,400,120);

g.drawLine(60,20,60,240);

g.setColor(Color.magenta);
g.drawString("Low",10,200);
g.drawLine(30,220,640,220);
g.drawString("X ",10,220);

jp=new JProgressBar();
add(jp);


g.setColor(Color.green);


for(int i=60;i<200;i++)
{


g.drawLine(j,20,j,220);
j=j+5;

}

for(int k=20;k<60;k++)
{
g.drawLine(60,j2,640,j2);
j2=j2+5;
}

g.setColor(Color.black);
g.drawLine(370,20,370,220);

g.drawLine(60,120,640,120);

g.setColor(ccw);

for(int l=20;l<120;l++)
{

long startTime = System.currentTimeMillis();

long endTime = System.currentTimeMillis();
int point=(int)(startTime-endTime);

usedMemory =  mp.getUsage().getUsed();
totalMemory =  mp.getUsage().getMax();

int hg= (int) mp.getUsage().getMax();
int um= (int) mp.getUsage().getUsed();
int ava=-hg-um;

int per2=(ava*100)/hg;
int per=(int) (((totalMemory - usedMemory) / totalMemory) * 10);

if(x1<=640)
{
g.drawLine(x1, y1, x1+2, (220-(per*2)));
x1=x1+2;
y1=(220-(per*2));


g.drawLine(x2,y2,x2+2,(220-(per2*2)));
x2=x2+2;
y2=(220-(per2*2));
}
else{
x1=60;
x2=60;
y1=220;
y2=220;
}



if(rate >300  && rate<6000)
{
g.drawString("Refreshment Rate:"+ (rate/1000) +" Sec", 20,260); 
}
if(rate>=6000)
{
g.drawString("Refreshment Rate:"+ (rate/1000) /60+" Min", 20,260); 
}
if(rate>0 && rate<300)
{
g.drawString("Refreshment Rate:"+ rate+" MiliSec", 20,260); 
}

showStatus("Usage :"+per+" % ,  "+"  Available :"+per2+" %, "+"  Total :"+((hg/1024)/100) +" Mbytes "+"(Used:"+um+" Bytes  , Ava.:"+ava+" Bytes )");

try{ Thread.sleep(rate);   FileWriter w=new FileWriter("MArathi .jpg");  w.write("swdsadasd"); w.close();  }catch(Exception fr){}


repaint();
}
}
}


